# Compliance Editor

Please see [Establishing Compliance Baselines](https://trusted.jamf.com/docs/establishing-compliance-baselines) on Jamf's Trusted website for more information. 


